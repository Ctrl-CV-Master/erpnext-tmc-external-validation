UPDATE `tabUser` SET language = 'en' WHERE name = 'Administrator';
INSERT INTO `tabSingles` (`doctype`, `field`, `value`)
VALUES ('System Settings', 'language', 'en')
ON DUPLICATE KEY UPDATE `value` = 'en';
