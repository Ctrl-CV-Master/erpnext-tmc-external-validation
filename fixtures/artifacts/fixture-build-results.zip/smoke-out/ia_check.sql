SELECT CONCAT(app_name, "=", is_setup_complete) FROM `tabInstalled Application`;
