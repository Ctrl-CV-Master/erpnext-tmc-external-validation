INSERT INTO `tabSingles` (`doctype`, `field`, `value`)
VALUES ('System Settings', 'setup_complete', '1')
ON DUPLICATE KEY UPDATE `value` = '1';
