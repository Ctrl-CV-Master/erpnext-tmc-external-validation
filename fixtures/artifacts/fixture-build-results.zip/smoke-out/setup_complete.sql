INSERT INTO `tabSingles` (`doctype`, `field`, `value`)
VALUES ('System Settings', 'setup_complete', '1')
ON DUPLICATE KEY UPDATE `value` = '1';
UPDATE `tabInstalled Application` SET `is_setup_complete`=1
WHERE app_name IN ('frappe', 'erpnext');
